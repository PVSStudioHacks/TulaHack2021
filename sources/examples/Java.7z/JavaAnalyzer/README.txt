Пример запуска:
   cd build
   java -jar TulaHackAnalyzer.jar "..\src\test\java\TestCases.java"