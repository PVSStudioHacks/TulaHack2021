public class TestCases {
    void printMessage(int a, int b, String message)
    {
        a = a++;
    }
}
