package com.tulahack;

import com.tulahack.spoon.Analyzer;
import com.tulahack.spoon.Utils;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        /* TODO
        *   По-хорошему тут нужна обработка аргументов
        *   А пока:
        *    arg[0] - исходные файлы/директории, разделенные ';'
        *    arg[1] - classpath, разделенны ';'
        * */

        Set<String> sources = Utils.getAllJavaFiles(Arrays.stream(args[0].split(";")).map(File::new).collect(Collectors.toSet()))
            .stream()
            .map(File::getAbsolutePath)
            .collect(Collectors.toSet());

        Set<String> classpath = new HashSet<>();
        if (args.length > 2) {
            classpath = Utils.getAllClasspathFiles(Arrays.stream(args[1].split(";")).map(File::new).collect(Collectors.toSet()))
                .stream()
                .map(File::getAbsolutePath)
                .collect(Collectors.toSet());
        }


        if (sources.isEmpty()) {
            System.out.println("Sources not found");
            return;
        }

        Analyzer analyzer = new Analyzer(sources, classpath);
        analyzer.analyze();
    }
}
