package com.tulahack.spoon;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Utils {
    private Utils() {
        throw new IllegalStateException("Utility class");
    }

    public static Set<File> getAllJavaFiles(@NotNull Set<File> resources) {
        return getAllFilesByExtension(resources, ".java");
    }

    public static Set<File> getAllClasspathFiles(@NotNull Set<File> resources) {
        return getAllFilesByExtension(resources, ".jar", ".class");
    }

    private static Set<File> getAllFilesByExtension(@NotNull Set<File> resources, @NotNull String... ext) {
        Set<File> allFiles = new HashSet<>();
        for (File resource : resources) {
            if (resource.isDirectory()) {
                Collection<File> filesDir = FileUtils.listFiles(resource, new SuffixFileFilter(ext), TrueFileFilter.INSTANCE);
                filesDir.forEach(f ->
                {
                    try {
                        allFiles.add(f.getCanonicalFile());
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            }
            else if (resource.isFile() && Arrays.stream(ext).anyMatch(s -> resource.getName().endsWith(s))) {
                try {
                    allFiles.add(resource.getCanonicalFile());
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return allFiles;
    }

}
