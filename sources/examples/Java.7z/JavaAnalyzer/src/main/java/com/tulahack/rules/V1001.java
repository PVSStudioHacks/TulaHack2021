package com.tulahack.rules;

import spoon.reflect.code.CtAssignment;
import spoon.reflect.code.CtExpression;
import spoon.reflect.code.CtUnaryOperator;
import spoon.reflect.code.CtVariableWrite;
import spoon.reflect.cu.SourcePosition;
import spoon.reflect.visitor.CtAbstractVisitor;

/*
*
* Диагностика, которая находит случаи: i = i++;
*
* */

public class V1001 extends CtAbstractVisitor {

    @Override
    public <T, A extends T> void visitCtAssignment(CtAssignment<T, A> assignement) {

        if (!(assignement.getAssignment() instanceof CtUnaryOperator) ||
            !(assignement.getAssigned() instanceof CtVariableWrite)
        ) {
            return;
        }

        CtExpression<?> operand = ((CtUnaryOperator<?>) assignement.getAssignment()).getOperand();
        if (operand.equals(assignement.getAssigned())) {
            SourcePosition position = assignement.getPosition();
            System.err.printf("Oops! Pattern 'i = i++'. File: %s:%s%n", position.getFile(), position.getLine());
        }
    }
}
