package com.tulahack.spoon;

import org.jetbrains.annotations.NotNull;
import spoon.reflect.declaration.CtElement;
import spoon.reflect.visitor.CtScanner;

public class Visitor extends CtScanner {

    private final Analyzer analyzer;
    public Visitor(@NotNull Analyzer analyzer)
    {
        this.analyzer = analyzer;
    }

    @Override
    public void scan(CtElement e) {
        if (e != null) {
            super.scan(e);
            analyzer.getRules().forEach(e::accept);
        }
    }
}
