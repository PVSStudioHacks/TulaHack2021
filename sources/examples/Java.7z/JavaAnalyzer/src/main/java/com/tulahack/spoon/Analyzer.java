package com.tulahack.spoon;

import com.tulahack.rules.V1001;
import spoon.Launcher;
import spoon.compiler.Environment;
import spoon.reflect.CtModel;
import spoon.reflect.declaration.CtType;
import spoon.reflect.visitor.CtAbstractVisitor;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Analyzer {

    private Launcher launcher = new Launcher();
    private final List<CtAbstractVisitor> rules = new ArrayList<>();

    public Analyzer(Set<String> sources, Set<String> classpath) {

        // spoon
        sources.forEach(launcher::addInputResource);
        Environment env = launcher.getEnvironment();
        env.setSourceClasspath(classpath.toArray(new String[0]));
        env.setCommentEnabled(true);
        env.setNoClasspath(true);

        // rules
        try {
            rules.add(V1001.class.newInstance());
            //....
        }
        catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }

    }

    public List<CtAbstractVisitor> getRules() {
        return rules;
    }

    public void analyze()
    {
        CtModel model;
        try {
            model = launcher.buildModel();
        }
        catch (Exception e) {
            System.err.println("Model build failed: " + e.getMessage());
            e.printStackTrace();
            return;
        }

        List<CtType<?>> classes = model.getAllTypes().stream().filter(CtType::isTopLevel).collect(Collectors.toList());
        new Visitor(this).scan(classes);
    }

}
