let esprima = require('esprima');
let program = 'let a = 10; a = a++; a = ++a;';
let parse = esprima.parseScript(program);
console.log(parse);

parse.body.forEach(element => {
    Rule1(element);
});

function Rule1(element) {
    if (element.type != 'ExpressionStatement')
        return;

    let expression = element.expression;
    if (expression.type != 'AssignmentExpression' || expression.operator != '=' )
        return;
     
    let left = expression.left;
    let right = expression.right;
    if (right.type != 'UpdateExpression' || right.prefix != false)
        return;

    let postfixType;
    if (right.operator == '++')
        postfixType = 'increment';
    else if (right.operator == '--')
        rostfixType = 'decrement';
    else 
        return; 

    if (!AreNodesTheSameVariable(left, right.argument))
        return;

    let msg = `Postfix ${postfixType} is senseless because this variable \'${left.name}\' is overwritten.`;
    console.log(msg);
}

function AreNodesTheSameVariable(left, right) {
    return left.type == 'Identifier' && right.type == 'Identifier' && left.name == right.name;
}