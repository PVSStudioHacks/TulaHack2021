function Main(param) {
    let i = param;
    i = i++;
}

Main(42);  

// 1. Имя переменной перепутали со строковым литералом, который содержит в себе имя переменной.
function Error1(userName) {
    let name = GetStrValue();
    if (userName == "name") { // <=
        // Do something
    }
}

// 2. Cчётчик цикла запустили не в ту сторону.
function Error2(content) {
    for (i = 0; i < content.length; i--) {// <=
        // Do something
    }
}

// 3. Сравнивают не то, что подразумевалось. Сopy-paste ошибка.
function Error3(a, b) {
    if (a.X == b.X && a.Y == b.Y && a.Z == b.Y) { // <=
        // Do something
    }
}

function GetStrValue() {
    return "Arthas";
}

Error1("Arthas");
Error2(["Moscow", "Tula"]);
Error3({X:1, Y:2, Z:2}, {X:1, Y:2, Z:3});