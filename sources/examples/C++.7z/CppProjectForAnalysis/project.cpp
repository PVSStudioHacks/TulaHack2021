auto GetValue()
{
  return 42;
}

void Example()
{
  auto i = GetValue();
  i = i++;
}
