При проверке clang-tidy строит модель проекта на основе так называемой compilation-database, которую можно получить используя Cmake:
- создадим каталог сборки
mkdir build & cd build
- вызовем Cmake для получения compilation-database
cmake -GNinja -DCMAKE_EXPORT_COMPILE_COMMANDS=ON ..

Следующей командой производится проверка тестового проекта через clang-tidy с нашей диагностикой:
"<корневая директори LLVM>/build/Release/bin/clang-tidy.exe" -checks=-*,misc-tulahack-* ../project.cpp --
здесь флаг '-checks=-*,misc-tulahack-*' отключает все другие диагностики, и включает только те, что начинаются с префикса 'misc-tulahack-'.

Примерный результат работы продемонстрирован на скриншоте result.png
