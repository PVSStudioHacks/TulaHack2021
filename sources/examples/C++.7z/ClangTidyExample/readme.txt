Этот гайд предполагает наличие установленных MS Visual Studio 2019 Community (с рабочей нагрузкой для C++), Git, CMake и Python:
https://visualstudio.microsoft.com/vs/community/
https://git-scm.com/downloads
https://cmake.org/download/
https://www.python.org/downloads/



Выберите удобную папку в качестве корневой директории
- скачиваем в неё LLVM через git
git clone https://github.com/llvm/llvm-project.git
- переходим в директорию clang-tidy
cd ./llvm-project/clang-tools-extra/clang-tidy

Создаем заготовку для диагностики
py add_new_check.py misc tulahack-meaningless-increment

Заменяем файлы ./misc/TulahackMeaninglessIncrementCheck.h и ./misc/TulahackMeaninglessIncrementCheck.cpp файлами из папки с демонстрационной диагностикой

Собираем clang-tidy
cd ../../ & mkdir build & cd build
cmake -DLLVM_ENABLE_PROJECTS="clang;clang-tools-extra" -DLLVM_TARGETS_TO_BUILD=X86 ../llvm
cmake --build . --config Release --target clang-tidy

В результате должен получиться исполняемый файл /Release/bin/clang-tidy.exe



Полезные ссылки (англ.):
Подробный гайд о создании диагностического правила для clang-tidy
https://clang.llvm.org/extra/clang-tidy/Contributing.html

Полезная статья о том, как собрать нужную информацию о AST для использования в clang-tidy
https://devblogs.microsoft.com/cppblog/exploring-clang-tooling-part-2-examining-the-clang-ast-with-clang-query/
